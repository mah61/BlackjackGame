﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BlackJack.Models
{
   public class BlackJackGame
     {
        public const int START_AMOUNT = 500;
        public const int CUTTING_POINTS = 21;
       
        public const int GAME_LOST = 200;
        public const int GAME_WIN = 100;
        public const int GAME_CONTINUE = 1;

        public string PlayerName { get; set; }
        public int AmountTotal { get; set; }
        public int BettingAmount { get; set; }
        public int PlayerCardTotal { get; set; }
        public int DealerCardTotal { get; set; }

        public IList<int> PlayerCardNumbers = new List<int>();
        public IList<int> DealerCardNumbers = new List<int>();

        public BlackJackGame()
        {

            AmountTotal = START_AMOUNT;
            BettingAmount = 0;
        }

        public int AddWinBettingAmount()
        {
            return AmountTotal += BettingAmount * 2;
        }

        public int SubtractBettingAmount()
        {
            return AmountTotal -= BettingAmount;
        }

        public int GetRandomCardForPlayer()
        {
            int number;
            Random rand = new Random();
            do
            {
                number = rand.Next(1, 53);
            } while ((PlayerCardNumbers.Contains(number)) || (DealerCardNumbers.Contains(number)));
            PlayerCardNumbers.Add(number);
            return number;
        }

        public int GetRandomCardForDealer()
        {
            int number;
            Random rand = new Random();
            do
            {
                number = rand.Next(1, 53);
            } while ((PlayerCardNumbers.Contains(number)) || (DealerCardNumbers.Contains(number)));
            DealerCardNumbers.Add(number);
            return number;
        }

        public string GetCardType(int cardNumber)
        {
            int cardType;

            if (cardNumber < 13)
            {
                cardType = 1;
            }
            else
            {
                cardType = cardNumber / 13;
            }
            if (cardType == 1)
            {
                return "C";
            }
            else if (cardType == 2)
            {
                return "D";
            }
            else if (cardType == 3)
            {
                return "H";
            }
            else
            {
                return "S";
            }
        }

        public String GetCardNumber(int cardNumber)
        {
            int Number = cardNumber % 13;
            if (Number > 2 && Number < 10)
            {
                return Number.ToString();
            }
            else if (Number == 11)
            {
                return "J";
            }
            else if (Number == 12)
            {
                return "Q";

            }
            else if (Number == 13)
            {
                return "K";
            }
            else
            {
                return "A";
            }
        }

        public int GetScore(int cardNumber)
        {
            int Number = cardNumber % 13;
            if (Number > 2 && Number < 10)
            {
                return Number;
            }

            else if (Number == 11 || Number == 12 || Number == 13)
            {
                return 10;
            }
            else
            {
                return 11;
            }  

        }

        public int GetScoreAce(int cardNumber)
        {
            int Number = cardNumber % 13;
            if (Number > 2 && Number < 10)
            {
                return Number;
            }

            else if (Number == 11 || Number == 12 || Number == 13)
            {
                return 10;
            }
            else
            {
                return 1;
            }

        }

        public int IsGameOver(int cardNumber, bool IsPlayer)
        {
            if (IsPlayer)
            {
                if (PlayerCardTotal < CUTTING_POINTS)
                {
                    int number = cardNumber % 13;
                    if (number == 11)
                    {
                        if ((PlayerCardTotal + number) > CUTTING_POINTS)
                        {
                            PlayerCardTotal += 1;
                        }
                        else
                        {
                            PlayerCardTotal += number;
                        }
                    }
                    else
                    {
                        PlayerCardTotal += number;
                    }
                    if (PlayerCardTotal == CUTTING_POINTS) return GAME_WIN;
                }
                if (PlayerCardTotal > CUTTING_POINTS) return GAME_LOST;
            }
            else
            {
                int number = cardNumber % 13;
                if (number == 11)
                {
                    if ((DealerCardTotal + number) > CUTTING_POINTS)
                    {
                        DealerCardTotal += 1;
                    }
                    else
                    {
                        DealerCardTotal += number;
                    }
                }
                else
                {
                    DealerCardTotal += number;
                }
                if (DealerCardTotal == CUTTING_POINTS) return GAME_WIN;

                if (DealerCardTotal > CUTTING_POINTS) return GAME_LOST;

            }

            return GAME_CONTINUE;
        }

        public bool IsGameOver(int cardTotal)
        {
            if (cardTotal > CUTTING_POINTS) return true;
            return false;
        }

        public void ResetTheCardCounts()
        {
            PlayerCardTotal = 0;
            DealerCardTotal = 0;

            PlayerCardNumbers.Clear();
            DealerCardNumbers.Clear();

        }

    }
}