﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BlackJack.Models
{
    public class Home
    {
        [Required]
        public string PlayerName;
        public int AmountTotal;

        [Required]
        public int BettingAmount;
    }
}