﻿using BlackJack.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BlackJack.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            Home home = new Home();
            BlackJackGame blackJackGame = new BlackJackGame();
            Session["BlackJackGame"] = blackJackGame;

            home.AmountTotal = blackJackGame.AmountTotal;
            home.PlayerName = blackJackGame.PlayerName;

            ViewBag.PlayerCardsPhoto = null;
            ViewBag.DealersCardsPhoto = null;

            ViewBag.disable = true;

            return View(home);
        }

        [HttpPost]
        public ActionResult Bet1(Home home)
        {
            ViewBag.disable = true;
            return View("Index", SetBettingAmount(1));
        }

        [HttpPost]
        public ActionResult Bet2(Home home)
        {
            ViewBag.disable = true;
            return View("Index", SetBettingAmount(2));            
        }

        [HttpPost]
        public ActionResult Bet5(Home home)
        {
            ViewBag.disable = true;
            return View("Index", SetBettingAmount(5));
        }

        [HttpPost]
        public ActionResult Bet10(Home home)
        {
            ViewBag.disable = true;
            return View("Index", SetBettingAmount(10));
        }

        [HttpPost]
        public ActionResult Bet20(Home home)
        {
            ViewBag.disable = true;
            return View("Index", SetBettingAmount(20));
        }

        [HttpPost]
        public ActionResult Bet50(Home home)
        {
            ViewBag.disable = true;
            return View("Index", SetBettingAmount(50));
        }

        [HttpPost]
        public ActionResult Bet100(Home home)
        {
            ViewBag.disable = true;
            return View("Index", SetBettingAmount(100));
        }

        
        public ActionResult StartGame(Home home)
        {
            IList<string> PlayerCardPhotos = new List<string>();
            IList<string> DealerCardPhotos = new List<string>();

            var blackJackGame = (BlackJackGame)Session["BlackJackGame"];
            string cardnum;
            String cardtype;
            int number;
            string image_file_name;
            int score = 0;
            int sumScorePlayer = 0;
            int sumScoreDealer = 0;
            ViewBag.disable = true;

            //Display two cards for Players
            for (int i = 0; i < 2; i++)
            {
                number = blackJackGame.GetRandomCardForPlayer();
                score = blackJackGame.GetScore(number);
                cardtype = blackJackGame.GetCardType(number);
                cardnum = blackJackGame.GetCardNumber(number);
                image_file_name = "~/Content/images/" + cardnum + cardtype + ".jpg";              
                PlayerCardPhotos.Add(image_file_name);

                sumScorePlayer += score;               
            }
            ////Increase amount of bet in blackJack
            if (sumScorePlayer == 21)
            {
                int halfAmount = (int)(blackJackGame.BettingAmount / 2);
                int winAmount  = blackJackGame.BettingAmount + halfAmount;
                blackJackGame.AmountTotal = blackJackGame.AmountTotal + winAmount;
                ViewBag.BlackJack = "BlackJack!!!";
                ViewBag.disable = false; //it makes disabled the hit and stand buttons
            }

            if (sumScorePlayer > 21)
            {
                ViewBag.LoseMessage = "You Lose!!!";
                blackJackGame.AmountTotal = blackJackGame.AmountTotal - blackJackGame.BettingAmount;
                ViewBag.disable = false;
            }

           // Display two cards for Dealers
                for (int i = 0; i < 1; i++)
                {
                    number = blackJackGame.GetRandomCardForDealer();
                    score = blackJackGame.GetScore(number);
                    cardtype = blackJackGame.GetCardType(number);
                    cardnum = blackJackGame.GetCardNumber(number);
                    image_file_name = "~/Content/images/" + cardnum + cardtype + ".jpg";
                    DealerCardPhotos.Add(image_file_name);

                    sumScoreDealer += score;
                }

            ViewBag.PlayerCardsPhoto = PlayerCardPhotos;
            ViewBag.DealersCardsPhoto = DealerCardPhotos;
            ViewBag.altText = "Card Image";

            //Save Cards data to session
            Session["blackJackGame"] = blackJackGame;
            Session["PlayerCardPhotos"] = PlayerCardPhotos;
            Session["DealerCardPhotos"] = DealerCardPhotos;
            Session["sumScoreDealer"] = sumScoreDealer;
            Session["sumScorePlayer"] = sumScorePlayer;
            Session["PlayerName"] = blackJackGame.PlayerName;

            home.AmountTotal = blackJackGame.AmountTotal = BlackJackGame.START_AMOUNT;
            //home.BettingAmount = blackJackGame.BettingAmount;
            home.PlayerName = blackJackGame.PlayerName;

            return View("Index", home);
        }

        public ActionResult Hit(Home home)
        {
            IList<string> PlayerCardPhotos =(List<string>)Session["PlayerCardPhotos"];
            IList<string> DealerCardPhotos =(List<string>)Session["DealerCardPhotos"];
            var blackJackGame = (BlackJackGame)Session["BlackJackGame"];
            string cardnum;
            String cardtype;
            int number;
            string image_file_name;
            int score = 0;
            int sumScorePlayer = (int)Session["sumScorePlayer"];
            int sumScoreDealer = (int)Session["sumScoreDealer"];
            ViewBag.disable = true;

            //Display a card for Players
            number = blackJackGame.GetRandomCardForPlayer();
            score = blackJackGame.GetScore(number);
            cardtype = blackJackGame.GetCardType(number);
            cardnum = blackJackGame.GetCardNumber(number);
            image_file_name = "~/Content/images/" + cardnum + cardtype + ".jpg";
            PlayerCardPhotos.Add(image_file_name);

            sumScorePlayer += score;


            ViewBag.PlayerCardsPhoto = PlayerCardPhotos;
            ViewBag.DealersCardsPhoto = DealerCardPhotos;
            ViewBag.altText = "Card Image";
            ViewBag.sumScorePlayer = sumScorePlayer;
            ViewBag.sumScoreDealer = sumScoreDealer;

            if (sumScorePlayer > 21)
            {
                ViewBag.LoseMessage = "You Lose!!!";
                blackJackGame.AmountTotal = blackJackGame.AmountTotal - blackJackGame.BettingAmount;
                ViewBag.disable = false;
            }
            else if (sumScorePlayer == 21)
            {
                ViewBag.WinMessage = "You Win!!!";
                blackJackGame.AmountTotal = blackJackGame.AmountTotal + blackJackGame.BettingAmount;
                
                ViewBag.disable = false;
            }

            else            

            //Save Cards data to session
            Session["blackJackGame"] = blackJackGame;
            Session["PlayerCardPhotos"] = PlayerCardPhotos;
            Session["DealerCardPhotos"] = DealerCardPhotos;
            Session["sumScorePlayer"] = sumScorePlayer;
            Session["sumScoreDealer"] = sumScoreDealer;

            home.AmountTotal = blackJackGame.AmountTotal;
            home.BettingAmount = blackJackGame.BettingAmount;
            home.PlayerName = blackJackGame.PlayerName;

            return View("Index", home);
        }

        public ActionResult Stand(Home home)
        {
            IList<string> PlayerCardPhotos = (List<string>)Session["PlayerCardPhotos"];
            IList<string> DealerCardPhotos = (List<string>)Session["DealerCardPhotos"];

            var blackJackGame = (BlackJackGame)Session["BlackJackGame"];
            string cardnum;
            String cardtype;
            int number;
            string image_file_name;
            int score = 0;
            int sumScorePlayer = (int)Session["sumScorePlayer"];
            int sumScoreDealer = (int)Session["sumScoreDealer"];
            ViewBag.disable = true;
            

            while (sumScoreDealer < 17)
            {
                if (sumScoreDealer < 11) //difference calculating for Ace
                {
                    number = blackJackGame.GetRandomCardForDealer();
                    cardtype = blackJackGame.GetCardType(number);
                    cardnum = blackJackGame.GetCardNumber(number);
                    score = blackJackGame.GetScore(number);//calculate 11 for Ace
                    image_file_name = "~/Content/images/" + cardnum + cardtype + ".jpg";
                    DealerCardPhotos.Add(image_file_name);
                    sumScoreDealer += score;
                }
                else
                {
                    number = blackJackGame.GetRandomCardForDealer();
                    cardtype = blackJackGame.GetCardType(number);
                    cardnum = blackJackGame.GetCardNumber(number);
                    score = blackJackGame.GetScoreAce(number);//calculate 1 for Ace
                    image_file_name = "~/Content/images/" + cardnum + cardtype + ".jpg";
                    DealerCardPhotos.Add(image_file_name);
                    sumScoreDealer += score;
                }
            }

            //if (sumScoreDealer > sumScorePlayer)
            //{
            //    ViewBag.LoseMessage = "You Lose!!!";
            //    blackJackGame.AmountTotal = blackJackGame.AmountTotal - blackJackGame.BettingAmount;
            //    ViewBag.disable = false;

            //}else ()

            //{
            //    ViewBag.WinMessage = "You Win!!!";
            //    blackJackGame.AmountTotal = blackJackGame.AmountTotal + blackJackGame.BettingAmount;
            //    ViewBag.disable = false;
            //}


            ViewBag.DealersCardsPhoto = DealerCardPhotos;
            ViewBag.PlayerCardsPhoto = PlayerCardPhotos;
            ViewBag.altText = "Card Image";
            ViewBag.sumScorePlayer = sumScorePlayer;
            ViewBag.sumScoreDealer = sumScoreDealer;


            if (sumScoreDealer > 21 || sumScoreDealer < sumScorePlayer)
            {
                ViewBag.WinMessage = "You Win!!!";
                blackJackGame.AmountTotal = blackJackGame.AmountTotal + blackJackGame.BettingAmount;
                ViewBag.disable = false;
            }
            else if (sumScoreDealer > sumScorePlayer)
            {
                ViewBag.LoseMessage = "You Lose!!!";
                blackJackGame.AmountTotal = blackJackGame.AmountTotal - blackJackGame.BettingAmount;
                ViewBag.disable = false;
            }
            else if (sumScoreDealer == 21)
            {
                ViewBag.LoseMessage = "You Lose!!!";
                int halfAmount = (int)(blackJackGame.BettingAmount / 2);
                int winAmount = blackJackGame.BettingAmount + halfAmount;
                blackJackGame.AmountTotal = blackJackGame.AmountTotal - winAmount;
                ViewBag.disable = false;
            }
            else


                //Save Cards data to session
            Session["blackJackGame"] = blackJackGame;
            Session["PlayerCardPhotos"] = PlayerCardPhotos;
            Session["DealerCardPhotos"] = DealerCardPhotos;
            Session["sumScorePlayer"] = sumScorePlayer;
            Session["sumScoreDealer"] = sumScoreDealer;

            home.AmountTotal = blackJackGame.AmountTotal;
            home.BettingAmount = blackJackGame.BettingAmount;

                        
            return View("Index", home);
 
        }

        public ActionResult NextRound(Home home)
        {
            IList<string> PlayerCardPhotos = new List<string>();
            IList<string> DealerCardPhotos = new List<string>();

            var blackJackGame = (BlackJackGame)Session["BlackJackGame"];
            string cardnum;
            String cardtype;
            int number;
            string image_file_name;
            int score = 0;
            int sumScorePlayer = 0;
            int sumScoreDealer = 0;
            ViewBag.disable = true;

            //Display two cards for Players
            for (int i = 0; i < 2; i++)
            {
                number = blackJackGame.GetRandomCardForPlayer();
                score = blackJackGame.GetScore(number);
                cardtype = blackJackGame.GetCardType(number);
                cardnum = blackJackGame.GetCardNumber(number);
                image_file_name = "~/Content/images/" + cardnum + cardtype + ".jpg";
                PlayerCardPhotos.Add(image_file_name);

                sumScorePlayer += score;
            }

            if (sumScorePlayer == 21)
            {
                int halfAmount = (int)(blackJackGame.BettingAmount / 2);
                int winAmount = blackJackGame.BettingAmount + halfAmount;
                blackJackGame.AmountTotal = blackJackGame.AmountTotal + winAmount;
                //blackJackGame.BettingAmount = blackJackGame.BettingAmount * 2;
                ViewBag.BlackJack = "BlackJack!!!";
                ViewBag.disable = false;
            }

            if (sumScorePlayer > 21)
            {
                ViewBag.LoseMessage = "You Lose!!!";
                blackJackGame.AmountTotal = blackJackGame.AmountTotal - blackJackGame.BettingAmount;
                ViewBag.disable = false;
            }

            //Display two cards for Dealers
            for (int i = 0; i < 1; i++)
            {
                number = blackJackGame.GetRandomCardForDealer();
                score = blackJackGame.GetScore(number);
                cardtype = blackJackGame.GetCardType(number);
                cardnum = blackJackGame.GetCardNumber(number);
                image_file_name = "~/Content/images/" + cardnum + cardtype + ".jpg";
                DealerCardPhotos.Add(image_file_name);

                sumScoreDealer += score;
            }

            ViewBag.PlayerCardsPhoto = PlayerCardPhotos;
            ViewBag.DealersCardsPhoto = DealerCardPhotos;
            ViewBag.altText = "Card Image";

            //Save Cards data to session
            Session["BlackJackGame"] = blackJackGame;
            Session["PlayerCardPhotos"] = PlayerCardPhotos;
            Session["DealerCardPhotos"] = DealerCardPhotos;
            Session["sumScoreDealer"] = sumScoreDealer;
            Session["sumScorePlayer"] = sumScorePlayer;

            home.AmountTotal = blackJackGame.AmountTotal;
            home.BettingAmount = blackJackGame.BettingAmount;

            if(blackJackGame.AmountTotal == 0 || blackJackGame.AmountTotal < 0)
            {
                ViewBag.GameOver = "Game Over!!!";
                ViewBag.disable = false;
            }

            return View("Index", home);
        }    


        public Home SetBettingAmount( int amount)
        {
            Home home = new Home();

            var blackJackGame = (BlackJackGame)Session["BlackJackGame"];
            home.AmountTotal = blackJackGame.AmountTotal;
            home.BettingAmount = blackJackGame.BettingAmount = amount;

            ViewBag.PlayerCardsPhoto = null;
            ViewBag.DealersCardsPhoto = null;


            Session["BlackJackGame"] = blackJackGame;

            return home;

        }


        public Home SetPlayerName()
        {
            Home home = new Home();

            var blackJackGame = (BlackJackGame)Session["BlackJackGame"];
            home.PlayerName = blackJackGame.PlayerName;          

            ViewBag.PlayerCardsPhoto = null;
            ViewBag.DealersCardsPhoto = null;


            Session["BlackJackGame"] = blackJackGame;

            return home;

        }

        public ActionResult AboutPlay()
        {

            return View("AboutPlay");
        }


    }
}